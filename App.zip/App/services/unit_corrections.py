﻿#!/usr/bin/env python3
"""services/unit_corrections.py — correcciones de flujo en la lectura.

Hay dos familias de correcciones historicas para flujo de combustible:

* LEAP-1A / LEAP-1B: algunos reportes quedaron guardados con el numero a la
  mitad del valor real. Se corrigen multiplicando por 2.
* CFM56-7B: algunos reportes vienen en magnitud kg/h aunque la serie se usa en
  lb/h. Se corrigen multiplicando por 2.2046226218.

La deteccion no depende solo del string de unidad, sino de (variante,
parametro, fecha del reporte). La correccion se hace EN LA LECTURA: no se
reingesta ni se edita motores.db. La etiqueta de unidad no se modifica.
"""

import pandas as pd
import streamlit as st

VALOR_DIVIDIDO_ENTRE_2_FACTOR = 2.0
KG_H_A_LB_H_FACTOR = 2.2046226218

# (variante, {raw_names}, operador de fecha, fecha de corte ISO, factor, etiqueta)
# operador "<"  -> se corrigen reportes ANTES de la fecha de corte
# operador ">"  -> se corrigen reportes DESPUES de la fecha de corte
# Ambos son estrictos: el dia exacto de corte NO se corrige en ninguna regla.
CORRECCIONES_FLUJO_COMBUSTIBLE = [
    ("1A",       {"WF36", "WFK"},      "<", "2026-03-01", VALOR_DIVIDIDO_ENTRE_2_FACTOR, "x2 por valor guardado a la mitad"),
    ("1B",       {"WFMR2", "WF36pph"}, "<", "2026-03-01", VALOR_DIVIDIDO_ENTRE_2_FACTOR, "x2 por valor guardado a la mitad"),
    ("CFM56-7B", {"WFK"},              ">", "2026-03-01", KG_H_A_LB_H_FACTOR, "kg/h a lb/h"),
]

def parametro_tiene_correccion(variant, param_label):
    """True si el parametro seleccionado cae en una regla de correccion."""
    if not variant or not param_label:
        return False
    raw_name = str(param_label).split(" [", 1)[0].strip()
    for rule_variant, raw_names, _operador, _fecha_corte, _factor, _label in CORRECCIONES_FLUJO_COMBUSTIBLE:
        if variant == rule_variant and raw_name in raw_names:
            return True
    return False


def checkbox_correccion(key, ayuda=None):
    """Checkbox 'Aplicar correccion de flujo', desactivado por defecto.

    Cada vista decide primero con parametro_tiene_correccion() si el
    parametro que tiene seleccionado en ESE momento la necesita, y solo
    entonces llama a este checkbox con una key propia (no compartida entre
    pestanas): asi el estado nunca queda atado al parametro de otra vista.
    """
    aplicar = st.checkbox(
        "Aplicar corrección de flujo", value=False,
        help=ayuda or "Aplica la correccion historica del flujo: LEAP x2; CFM56-7B kg/h a lb/h "
                       "(ver services/unit_corrections.py).",
        key=key,
    )
    if not aplicar:
        st.caption("Corrección de flujo apagada: se muestran valores crudos.")
    return aplicar


def apply_unit_corrections(df):
    """Aplica CORRECCIONES_FLUJO_COMBUSTIBLE sobre el DataFrame ya cargado.

    Requiere que df ya tenga las columnas 'variant', 'raw_name', 'value' y
    'fecha' (datetime64). Multiplica 'value' in-place por el factor definido en la regla
    (variante + parametro + ventana de fecha); no toca 'unit'.

    Fechas no parseables (NaT) nunca cumplen '<' ni '>', asi que esas filas
    no se corrigen (ya se avisan aparte por date_parse_status).

    Esta funcion se llama una sola vez por carga, sobre los valores crudos
    que vienen de motores.db (services/data_loader.load_data), que nunca se
    modifica: no hay riesgo de aplicar la correccion dos veces sobre un
    valor ya corregido en el flujo normal de la app.
    """
    for variant, raw_names, operador, fecha_corte, factor, _label in CORRECCIONES_FLUJO_COMBUSTIBLE:
        corte = pd.Timestamp(fecha_corte)
        if operador == "<":
            cumple_fecha = df["fecha"] < corte
        elif operador == ">":
            cumple_fecha = df["fecha"] > corte
        else:
            raise ValueError(f"operador de fecha no soportado: {operador!r}")

        mask = (
            (df["variant"] == variant)
            & df["raw_name"].isin(raw_names)
            & cumple_fecha
        )
        if mask.any():
            df.loc[mask, "value"] = df.loc[mask, "value"] * factor

    return df






