# Manual de usuario

## Trend Monitoring - Celda de Pruebas de Motores

| Campo | Valor |
|---|---|
| Documento | Manual de usuario |
| Aplicación | Trend Monitoring - Celda de Pruebas de Motores |
| Estado | Borrador para validación |
| Fecha | 15 de julio de 2026 |
| Versión del documento | 1.0 |

## 1. Objetivo

Trend Monitoring permite consultar el comportamiento histórico de parámetros
de motores y de la instrumentación de la celda de pruebas. La aplicación ayuda
a identificar tendencias, correlaciones, cambios de nivel y señales que
requieren revisión.

La aplicación es una herramienta de apoyo al análisis. Una alerta, un punto
fuera de banda o una señal CUSUM no demuestra por sí sola una falla del motor o
de la celda. El resultado debe revisarse junto con el reporte de prueba, la
condición operativa y el criterio del especialista responsable.

## 2. Alcance

El manual cubre:

- Carga de reportes Excel mediante **Sync**.
- Selección de variante, rating/punto y fechas.
- Tendencia, correlación y correlación contra referencia.
- Revisión y clasificación de anomalías.
- Vigilancia de modificadores de celda.
- Registro de eventos.
- Consulta y retiro controlado de puntos.
- Administración de parámetros y vistas favoritas.
- Exportación de resultados.

## 3. Requisitos previos

Antes de abrir la aplicación, confirme que:

1. Python y las dependencias del proyecto están instalados.
2. La carpeta `App` contiene `app.py`, `mapping.yaml` y la carpeta `data`.
3. Las carpetas `Loaded` y `Unloaded` están junto a `App`.
4. Los archivos nuevos son `.xls`, `.xlsx` o `.xlsm` y contienen la hoja
   `Buffer` esperada por el ETL.

Estructura recomendada:

```text
Trend Monitoring/
|-- App/
|-- Loaded/
|   |-- LEAP-1A/
|   |-- LEAP-1B/
|   |-- CFM56-5A/
|   `-- CFM56-7B/
`-- Unloaded/
```

## 4. Inicio de la aplicación

Abra una terminal en la carpeta `App` y ejecute:

```powershell
streamlit run app.py
```

La aplicación se abre normalmente en `http://localhost:8501`.

Si la base no existe o está vacía, la pantalla mostrará una advertencia. En ese
caso cargue reportes mediante **Sync** o ejecute el ETL autorizado por el
administrador.

## 5. Pantalla principal

La pantalla se divide en tres zonas:

- **Encabezado:** título, botón **Parámetros** y botón **Sync**.
- **Barra lateral:** filtros generales y controles de análisis de Tendencia.
- **Área principal:** pestañas Tendencia, Correlación, Correlación Ref.,
  Anomalías, Modificadores, Eventos y Datos.

Los filtros generales afectan las vistas que utilizan la selección visible.
La pestaña Modificadores es una excepción: analiza el histórico completo de la
variante, separado por rating.

## 6. Carga de reportes con Sync

1. Coloque los Excel nuevos en `Unloaded`.
2. Abra la aplicación.
3. Presione **Sync** en la esquina superior derecha.
4. Revise el resumen mostrado por la aplicación.

Los archivos procesados correctamente se mueven a
`Loaded/<variante>/`. Los duplicados y archivos con error permanecen en
`Unloaded` para su revisión.

El proceso es idempotente: volver a procesar un archivo ya cargado no debe
crear un segundo punto. No renombre ni modifique archivos de `Loaded` sin un
procedimiento controlado.

Interpretación del resultado de Sync:

- **Cargados:** reportes incorporados correctamente.
- **Movidos a Loaded:** archivos archivados en la carpeta de su variante.
- **Duplicados:** archivos identificados como ya procesados.
- **Con error:** archivos que no cumplieron el formato o no pudieron leerse.

Abra **Detalle del sync** cuando existan duplicados, errores de lectura o
errores al mover archivos.

## 7. Filtros generales

### 7.1 Variante de motor

Seleccione una sola variante. El cambio actualiza los ratings, parámetros y
datos disponibles en las demás vistas.

### 7.2 Rating / Punto

Permite seleccionar uno o varios ratings/puntos. El número entre paréntesis
indica la cantidad de puntos disponibles para el parámetro actual cuando ese
conteo aplica.

Para análisis estadísticos de bandas, umbrales o baseline se recomienda
seleccionar un solo rating/punto, salvo que el procedimiento de análisis
indique expresamente lo contrario.

### 7.3 Rango de fechas

Las opciones son:

- **Histórico completo:** no limita por fecha.
- **Rango personalizado:** habilita rangos rápidos o fechas Desde/Hasta.

Los rangos rápidos se calculan a partir del último reporte disponible de la
selección, no de la fecha actual.

### 7.4 Vistas favoritas

Una vista favorita conserva la variante, parámetro, ratings/puntos y periodo.

1. Configure los filtros deseados.
2. Escriba un nombre descriptivo.
3. Presione **Guardar vista actual**.

Para reutilizarla, selecciónela y presione **Aplicar**. El botón **Borrar**
elimina la configuración guardada, no los datos de prueba.

## 8. Pestaña Tendencia

### 8.1 Tendencia de un parámetro

1. Desactive **Modo comparación**.
2. Seleccione el parámetro.
3. Pase el cursor sobre un punto para consultar reporte, valor, rating/punto,
   fecha y archivo de origen.

El eje X utiliza el consecutivo real del reporte. Los saltos en la numeración
pueden corresponder a filtros o a reportes que no contienen el parámetro.

### 8.2 Bandas y baseline

Abra **Bandas / baseline** en la barra lateral.

- **Mostrar bandas (+/-N sigma):** dibuja límites estadísticos.
- **N (sigma):** modifica la amplitud de los límites.
- **Histórico completo:** calcula media y sigma con el histórico del rating.
- **Visible:** calcula con los puntos visibles después de filtrar.
- **Rango manual:** usa un periodo específico como referencia.
- **Baseline aprobado:** utiliza estadísticas congeladas de un perfil aprobado.

No interprete automáticamente un punto fuera de banda como falla. Revise el
tamaño del baseline, cambios de configuración, eventos y calidad del dato.

### 8.3 Regresión

Abra **Tendencia / regresión** y active **Línea de tendencia (regresión)**.
La opción **Proyectar N reportes adelante** extiende la recta sobre reportes
futuros hipotéticos.

La proyección es una extrapolación matemática, no un pronóstico garantizado.
Evite interpretarla con pocos puntos, cambios de régimen o ratings mezclados.

### 8.4 Detección de drift

Abra **Detección de drift** y active la función.

- **Ventana media móvil:** cantidad de reportes incluidos en cada promedio.
- **CUSUM k:** holgura antes de acumular desviaciones.
- **CUSUM H:** límite que dispara una señal de deriva.

CUSUM busca cambios sostenidos respecto al baseline. Una señal debe
correlacionarse con eventos, modificadores y condiciones de prueba.

### 8.5 Eventos en la gráfica

Active la visualización de eventos para mostrar líneas en las fechas de
actualizaciones, recalibraciones o cambios de sensor registrados en la pestaña
Eventos.

### 8.6 Corrección histórica de flujo

Cuando el parámetro y la variante tienen una regla aplicable, aparece
**Aplicar corrección de flujo**. Está desactivada por defecto.

- LEAP-1A y LEAP-1B: la regla aplicable corrige determinados valores
  históricos multiplicándolos por 2.
- CFM56-7B: la regla aplicable convierte determinados valores con el factor
  2.2046226218.

La corrección se aplica solamente para visualizar y analizar. No modifica el
valor crudo almacenado ni vuelve a ejecutar el ETL.

### 8.7 Exportación

En la parte inferior de Tendencia puede descargar:

- **Excel:** datos, configuración del análisis, estadísticas y gráfica.
- **PDF:** resumen del análisis y gráfica.

Revise que variante, parámetro, rating, fechas, baseline y corrección de flujo
sean los deseados antes de exportar.

## 9. Pestaña Correlación

Esta vista compara dos parámetros medidos en el mismo punto de prueba.

1. Seleccione el parámetro del **Eje X**.
2. Seleccione un parámetro distinto para el **Eje Y**.
3. Revise la nube de puntos.
4. Pase el cursor sobre un punto para consultar rating, fecha, archivo y
   consecutivo.

Solo aparecen puntos que contienen ambos parámetros. Una correlación visual no
demuestra causalidad. Cambios de rating, configuración o celda pueden producir
grupos distintos.

## 10. Pestaña Correlación Ref.

Compara los puntos reales del motor contra las curvas del archivo de referencia
de la celda.

La hoja del archivo `Datos Correlacion.xlsx` debe llamarse igual que la
variante mostrada por la app. Actualmente se admiten `LEAP-1A`, `LEAP-1B` y
`CFM56-7B`. Cada hoja utiliza seis bloques: N1R-N2R, N1R-FNR, N1R-WFR,
N1R-W2R, N1R-EGTR y W2R-FNR.

Controles principales:

- **Grado del polinomio:** define el ajuste de la referencia.
- **Mostrar bandas +/-N sigma:** activa o desactiva bandas y clasificación.
- **N sigma:** ajusta la amplitud de las bandas.

Con las bandas activas, los puntos se clasifican dentro o fuera. Con las bandas
apagadas, los puntos se muestran sin clasificación y no deben interpretarse
como rechazados.

Para `CFM56-7B`, esta vista convierte localmente el `FNK` histórico de daN a
lbf antes de compararlo con los pares que usan FNR. La conversión no modifica
la base ni el valor mostrado en las demás pestañas.

También convierte localmente el `EGTK` histórico de grados Celsius a Kelvin
antes de compararlo con el par N1R-EGTR. La curva de referencia no se modifica
y las demás pestañas continúan mostrando el valor histórico en grados Celsius.

Cuando existan puntos fuera de banda, la tabla permite seleccionar una o varias
filas y ocultar los puntos asociados. Ocultar no elimina el punto de la base.
Revise cuidadosamente el alcance seleccionado:

- Solo el par de correlación actual.
- Toda la vista Correlación Ref.
- Global, para todas las pestañas.

Use el panel de puntos ocultos para restaurarlos.

## 11. Pestaña Anomalías

Consolida señales de outliers, umbrales, CUSUM y rachas.

1. Ajuste **N sigma**, **CUSUM k** y **CUSUM H**.
2. Seleccione el baseline de detección.
3. Filtre por severidad, estado y tipo.
4. Revise el reporte y la evidencia asociada.
5. Cambie el estado a **Revisada** o **Descartada** y agregue una nota.
6. Presione **Guardar cambios de estado**.

Estados disponibles:

- **Pendiente:** requiere evaluación.
- **Revisada:** fue evaluada y debe conservarse como hallazgo.
- **Descartada:** fue evaluada y se determinó que no representa un hallazgo.

La severidad sirve para priorizar la revisión; no sustituye una decisión de
ingeniería.

## 12. Pestaña Modificadores

Vigila cambios de nivel en los modificadores de la celda por rating. Esta vista
usa el histórico completo de la variante aunque la barra lateral tenga un
periodo o ratings filtrados.

Use **Tolerancia para considerar mismo nivel** para separar ruido pequeño de un
cambio real. Una transición en varios ratings y en una fecha similar puede
indicar una recalibración de celda. Una transición aislada merece revisar el
reporte y el archivo de origen.

## 13. Pestaña Eventos

Los eventos documentan cambios que pueden explicar una tendencia.

Para crear un evento:

1. Abra **Crear nuevo evento**.
2. Seleccione fecha y alcance.
3. Escriba nombre y descripción.
4. Presione **Agregar evento**.

El alcance puede ser todas las variantes o una variante específica. Los
eventos existentes pueden editarse o borrarse desde su desplegable.

## 14. Pestaña Datos

Muestra las mediciones correspondientes a los filtros actuales.

### 14.1 Seleccionar puntos

La selección es por filas, pero el retiro afecta al punto de prueba completo y
todas sus mediciones. Puede seleccionar varias filas y puntos.

### 14.2 Retirar puntos

1. Escriba la carpeta donde están los Excel de origen.
2. Seleccione las filas correspondientes.
3. Confirme el número de puntos y Exceles asociados.
4. Registre el motivo del retiro.
5. Presione **Retirar puntos y mover Exceles a cuarentena**.

El Excel no se elimina definitivamente: se mueve a la carpeta de cuarentena y
el retiro queda registrado. De manera predeterminada, la operación se bloquea
si falta algún Excel de origen.

La opción **Permitir retirar puntos aunque no se encuentre su Excel** debe
usarse únicamente con autorización, porque permite retirar el registro sin
asegurar primero la evidencia primaria.

Para reincorporar un archivo, muévalo manualmente desde la ruta indicada en el
historial de cuarentena a la carpeta de carga autorizada y ejecute nuevamente
el ETL o Sync conforme al procedimiento local.

## 15. Administración de parámetros

Presione **Parámetros** en el encabezado.

- Mover un parámetro a **Inactivos** lo oculta de los desplegables de Tendencia
  y Correlación; no borra mediciones.
- Moverlo a **Activos** vuelve a mostrarlo.
- **Cancelar** descarta los cambios del diálogo.
- **OK** guarda la selección.

**Cargar nuevos parámetros** busca nombres crudos de la hoja `Buffer` en los
Excel ya almacenados en `Loaded` y los registra para cargas futuras. Esta
acción sí puede agregar mediciones a la base; confirme el nombre exacto y las
variantes antes de ejecutarla.

## 16. Mensajes frecuentes

### No hay datos con los filtros actuales

Active al menos un rating/punto, amplíe el periodo o seleccione otra variante.

### Hay fechas sin interpretar o faltantes

Revise esos puntos en Datos antes de confiar en tendencias o análisis
cronológicos.

### No aparece un parámetro

Compruebe que esté activo en Parámetros. Si nunca fue cargado, revise su nombre
en la hoja `Buffer`, `mapping.yaml` y el proceso de resincronización.

### Sync deja un archivo en Unloaded

Abra el detalle. Las causas habituales son archivo duplicado, hoja `Buffer`
ausente, formato inesperado, archivo abierto/bloqueado o variante no
identificada.

### Correlación no muestra puntos

Confirme que los dos parámetros existan en los mismos puntos y que los filtros
no hayan eliminado todas las coincidencias.

### La banda o anomalía parece incorrecta

Compruebe el rating seleccionado, baseline, periodo, N sigma, corrección de
flujo y cantidad de puntos. Compare después con el Excel de origen.

## 17. Buenas prácticas

- Revise siempre la variante y el rating antes de interpretar una gráfica.
- Use un solo rating para establecer baselines y límites estadísticos.
- Documente recalibraciones y cambios de software como eventos.
- No cambie parámetros estadísticos solo para hacer desaparecer una alerta.
- Añada una nota al cambiar el estado de una anomalía.
- Use ocultamiento para exclusiones visuales reversibles.
- Use retiro y cuarentena únicamente para datos que deban salir del conjunto.
- Mantenga respaldos controlados de las bases y de las carpetas de Excel.
- Valide los resultados exportados antes de distribuirlos.

## 18. Glosario

- **Baseline:** conjunto de referencia utilizado para calcular media y sigma.
- **CUSUM:** suma acumulada usada para detectar desplazamientos sostenidos.
- **Drift:** cambio gradual o sostenido del comportamiento de un parámetro.
- **Outlier:** punto alejado de su referencia estadística.
- **Rating/Punto:** condición o punto de operación de la prueba.
- **Sigma:** desviación estándar del conjunto de referencia.
- **Cuarentena:** ubicación controlada para archivos retirados del dashboard.
- **Consecutivo:** número de orden histórico asignado al reporte.

## 19. Control y aprobación

Antes de liberar este manual junto con la aplicación, complete:

| Rol | Nombre | Firma/aprobación | Fecha |
|---|---|---|---|
| Propietario del proceso |  |  |  |
| Especialista de pruebas de motores |  |  |  |
| Responsable de calidad/validación |  |  |  |
| Responsable de la aplicación |  |  |  |

Registre toda modificación funcional de la aplicación en una nueva revisión
del manual y vuelva a validar las secciones afectadas.
