﻿#!/usr/bin/env python3
"""views/sidebar.py — filtros de la barra lateral (vistas favoritas,
variante, description, rango de fechas).

Extraida de app.py sin cambios de logica. Devuelve un objeto Filtros que
las vistas reciben en render(filtros).
"""

from dataclasses import dataclass, field
from pathlib import Path
import datetime as dt
import streamlit as st
import pandas as pd
import streamlit as st

import config_store as cfg

LOGO_PATH = Path(__file__).resolve().parents[1] / "assets" / "logo_empresa.png"

@dataclass
class Filtros:
    """Estado de los filtros del sidebar + datos ya filtrados.

    fdf: datos con TODOS los filtros aplicados (variante, description, fechas).
    dfv_hist: historico completo de la variante activa (sin fechas ni
    description), para bandas/baseline sobre toda la historia.
    """
    fdf: pd.DataFrame
    dfv_hist: pd.DataFrame
    sel_var: str
    sel_lbl: str
    sel_desc: list
    variantes: list
    etiqueta: dict = field(default_factory=dict)


def render_sidebar(df):

    if LOGO_PATH.exists():
        st.sidebar.image(str(LOGO_PATH), width=160)
    st.sidebar.header("Filtros")

    variantes = sorted(df["variant"].dropna().unique())


    def etiqueta_variante(v):
        return f"LEAP-{v}" if v in ("1A", "1B") else str(v)


    etiqueta = {v: etiqueta_variante(v) for v in variantes}
    inv_etiqueta = {lbl: v for v, lbl in etiqueta.items()}

    # Seleccion UNICA de variante (radio): nunca dos activas a la vez.
    # El multiselect de ratings usa una key compartida entre variantes; se
    # limpia en el callback para que el frontend no restaure ratings (o una
    # seleccion vacia) de la variante anterior durante el siguiente rerun.
    def _al_cambiar_variante():
        nueva_etiqueta = st.session_state.get("f_variant")
        nueva_variante = inv_etiqueta.get(nueva_etiqueta)
        nuevas_descripciones = sorted(
            df.loc[df["variant"] == nueva_variante, "description"]
            .dropna()
            .unique()
        )
        st.session_state["f_desc"] = nuevas_descripciones

    labels_var = [etiqueta[v] for v in variantes]
    sel_lbl = st.sidebar.radio(
        "Variante de motor", labels_var, key="f_variant",
        on_change=_al_cambiar_variante,
    )
    sel_var = inv_etiqueta[sel_lbl]

    dfv = df[df["variant"] == sel_var].copy()
    # historico completo de la variante (sin filtros de fecha/description),
    # para calcular bandas de control sobre toda la historia
    dfv_hist = dfv.copy()

    # Filtro de Rating / Punto (texto completo, seleccion multiple, default todos)
    descripciones = sorted(dfv["description"].dropna().unique())
    sel_desc = list(descripciones)
    if descripciones:
        # Contar puntos/reportes unicos por rating. Si ya hay un parametro
        # seleccionado (por ejemplo EGTK), el conteo corresponde a ese parametro;
        # si no, usa todos los puntos cargados del rating.
        param_actual = st.session_state.get("f_param")
        base_conteo = dfv
        if param_actual and "param_label" in dfv.columns and param_actual in set(dfv["param_label"].dropna()):
            base_conteo = dfv[dfv["param_label"] == param_actual]
        conteo_desc = (
            base_conteo[["description", "point_id"]]
            .dropna(subset=["description"])
            .drop_duplicates()
            .groupby("description")["point_id"]
            .nunique()
            .to_dict()
        )

        def etiqueta_desc(desc):
            return f"{desc} ({int(conteo_desc.get(desc, 0))})"

        # Conserva las selecciones que tambien existan en la nueva variante.
        # Si ninguna coincide (caso normal al cambiar de familia), reemplaza
        # el estado del widget por todos los ratings validos. Pasar solamente
        # ``default`` no basta porque Streamlit prioriza el valor persistido
        # de una key existente y dejaba el filtro vacio.
        default_desc = descripciones
        if "f_desc" in st.session_state:
            guardados = [d for d in st.session_state["f_desc"] if d in descripciones]
            if guardados:
                st.session_state["f_desc"] = guardados
                default_desc = guardados
            else:
                # Al cambiar a una variante sin ratings en comun, hay que
                # retirar por completo el estado del widget. Si solo se le
                # asigna una lista nueva, el frontend puede restaurar la
                # seleccion vacia del widget anterior durante el rerun.
                st.session_state.pop("f_desc", None)
        sel_desc = st.sidebar.multiselect(
            "Rating / Punto", descripciones, default=default_desc,
            format_func=etiqueta_desc,
            help="Filtra por Rating / Punto. El numero entre parentesis es la cantidad de puntos cargados para el parametro actual cuando aplica.",
            key="f_desc",
        )
        dfv = dfv[dfv["description"].isin(sel_desc)]

    # Filtro de rango de fechas. Por default no filtra: muestra el historico completo.
    # Cuando se elige rango personalizado, los presets se calculan contra el ultimo
    # reporte disponible de la seleccion actual, no contra la fecha de hoy.
    fechas_validas = dfv["fecha"].dropna()
    if not fechas_validas.empty:
        fmin = fechas_validas.min().date()
        fmax = fechas_validas.max().date()

        def _rango_rapido(dias):
            return (max(fmin, fmax - dt.timedelta(days=dias)), fmax)

        presets_fecha = {
            "ultimo_mes": _rango_rapido(31),
            "ultimos_3_meses": _rango_rapido(92),
            "ultimos_6_meses": _rango_rapido(183),
            "ultimo_ano": _rango_rapido(365),
            "ultimos_2_anos": _rango_rapido(730),
            "manual": None,
        }
        etiquetas_preset = {
            "ultimo_mes": "Último mes",
            "ultimos_3_meses": "Últimos 3 meses",
            "ultimos_6_meses": "Últimos 6 meses",
            "ultimo_ano": "Último año",
            "ultimos_2_anos": "Últimos 2 años",
            "manual": "Manual",
        }
        alias_preset = {
            "Último mes": "ultimo_mes",
            "Últimos 3 meses": "ultimos_3_meses",
            "Últimos 6 meses": "ultimos_6_meses",
            "Último año": "ultimo_ano",
            "Últimos 2 años": "ultimos_2_anos",
            "Ultimo mes": "ultimo_mes",
            "Ultimos 3 meses": "ultimos_3_meses",
            "Ultimos 6 meses": "ultimos_6_meses",
            "Ultimo ano": "ultimo_ano",
            "Ultimos 2 anos": "ultimos_2_anos",
            "Manual": "manual",
        }
        opciones_preset = list(presets_fecha.keys())
        default_inicio, default_fin = presets_fecha["ultimos_2_anos"]
        def _normalizar_rango(valor):
            if not isinstance(valor, (tuple, list)) or len(valor) != 2:
                return (default_inicio, default_fin)
            try:
                d0 = pd.to_datetime(valor[0]).date()
                d1 = pd.to_datetime(valor[1]).date()
            except Exception:
                return (default_inicio, default_fin)
            d0 = min(max(d0, fmin), fmax)
            d1 = min(max(d1, fmin), fmax)
            if d0 > d1:
                return (default_inicio, default_fin)
            return (d0, d1)

        start_key = f"f_fecha_desde_v3_{sel_var}_{fmin.isoformat()}_{fmax.isoformat()}"
        end_key = f"f_fecha_hasta_v3_{sel_var}_{fmin.isoformat()}_{fmax.isoformat()}"
        preset_key = f"f_fecha_preset_v1_{sel_var}_{fmin.isoformat()}_{fmax.isoformat()}"

        rango_guardado = st.session_state.get("f_fechas")
        if isinstance(rango_guardado, (tuple, list)) and len(rango_guardado) == 2:
            d0_def, d1_def = _normalizar_rango(rango_guardado)
            preset_default = "manual"
        else:
            d0_def, d1_def = default_inicio, default_fin
            preset_default = "ultimos_2_anos"

        valor_preset_actual = st.session_state.get(preset_key)
        valor_preset_actual = alias_preset.get(valor_preset_actual, valor_preset_actual)
        if valor_preset_actual not in opciones_preset:
            valor_preset_actual = preset_default
        st.session_state[preset_key] = valor_preset_actual
        st.session_state[start_key] = _normalizar_rango((st.session_state.get(start_key, d0_def), d1_def))[0]
        st.session_state[end_key] = _normalizar_rango((d0_def, st.session_state.get(end_key, d1_def)))[1]
        if st.session_state[start_key] > st.session_state[end_key]:
            st.session_state[start_key], st.session_state[end_key] = (d0_def, d1_def)

        with st.sidebar.expander("Rango de fechas", expanded=False):
            modo_fecha = st.radio(
                "Periodo", ["Historico completo", "Rango personalizado"],
                key="f_fecha_modo",
            )
            if modo_fecha == "Rango personalizado":
                preset = st.selectbox("Rango rápido", opciones_preset, key=preset_key, format_func=etiquetas_preset.get)
                if preset != "manual":
                    st.session_state[start_key], st.session_state[end_key] = presets_fecha[preset]

                def _marcar_rango_manual():
                    st.session_state[preset_key] = "manual"

                d0 = st.date_input(
                    "Desde", value=st.session_state[start_key],
                    min_value=fmin, max_value=fmax, key=start_key,
                    on_change=_marcar_rango_manual,
                )
                d1 = st.date_input(
                    "Hasta", value=st.session_state[end_key],
                    min_value=fmin, max_value=fmax, key=end_key,
                    on_change=_marcar_rango_manual,
                )
                d0, d1 = _normalizar_rango((d0, d1))
                rango = (d0, d1)
            else:
                rango = None

        if modo_fecha == "Rango personalizado" and isinstance(rango, tuple) and len(rango) == 2:
            d0, d1 = rango
            st.session_state["f_fechas"] = (d0, d1)
            dfv = dfv[(dfv["fecha"].dt.date >= d0) & (dfv["fecha"].dt.date <= d1)]
    # --- Vistas favoritas (aplicar / guardar / borrar) ---
    with st.sidebar.expander("Vistas favoritas", expanded=False):
        vistas = cfg.list_views()
        nombres_vistas = [v["name"] for v in vistas]
        if nombres_vistas:
            vsel = st.selectbox("Vista guardada", ["(ninguna)"] + nombres_vistas,
                                key="vw_sel")
            cva, cvb = st.columns(2)
            with cva:
                if st.button("Aplicar", key="vw_apply") and vsel != "(ninguna)":
                    payload = cfg.get_view(vsel)
                    if payload:
                        # escribir en session_state las keys de los filtros
                        var_p = payload.get("variant")
                        if var_p in variantes:
                            st.session_state["f_variant"] = etiqueta[var_p]
                        if payload.get("param"):
                            st.session_state["f_param"] = payload["param"]
                        if payload.get("desc"):
                            st.session_state["f_desc"] = payload["desc"]
                        if payload.get("d0") and payload.get("d1"):
                            import datetime as _d
                            try:
                                st.session_state["f_fechas"] = (
                                    _d.date.fromisoformat(payload["d0"]),
                                    _d.date.fromisoformat(payload["d1"]))
                                st.session_state["f_fecha_modo"] = "Rango personalizado"
                            except Exception:
                                pass
                        elif payload.get("fecha_modo"):
                            st.session_state["f_fecha_modo"] = payload["fecha_modo"]
                        st.rerun()
            with cvb:
                if st.button("Borrar", key="vw_del") and vsel != "(ninguna)":
                    cfg.delete_view(vsel)
                    st.success("Vista borrada.")
                    st.rerun()
        else:
            st.caption("Aun no hay vistas guardadas. Guarda una abajo.")

        nueva_vista = st.text_input("Nombre para guardar vista actual", key="vw_new_name",
                                    placeholder="Ej: EGT TKO 1B")
        guardar_vista = st.button("Guardar vista actual", key="vw_save")


    fdf = dfv

    return Filtros(
        fdf=fdf,
        dfv_hist=dfv_hist,
        sel_var=sel_var,
        sel_lbl=sel_lbl,
        sel_desc=sel_desc,
        variantes=variantes,
        etiqueta=etiqueta,
    )





